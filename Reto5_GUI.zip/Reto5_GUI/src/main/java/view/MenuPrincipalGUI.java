package view;

import java.sql.SQLException;
import controller.ControladorRequerimientosReto4;
import model.vo.ProyectoRankeadoCompras;
import model.vo.BancoRankeadoAreaPromedio;
import model.vo.MaterialRankeadoCompras;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.text.AttributeSet.ColorAttribute;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.color.*;

import controller.ControladorRequerimientosReto4;
//import java.util.Scanner;

public class MenuPrincipalGUI extends JFrame{

    //Atributo -> Controlador necesario para el funcionamiento de la vista
    
    private JButton btnRequerimiento1;
    private JButton btnRequerimiento2;
    private JButton btnRequerimiento3;
    private JButton btnCRUD_Materiales;

    // Constructor para realizar la composición de la ventana

    public MenuPrincipalGUI(){


    }

    private ImageIcon redimensionarIcono(ImageIcon icono,int pixeles){
        Image imagen = icono.getImage();
        Image newimg = imagen.getScaledInstance(pixeles, pixeles, java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(newimg);        
    }

    //Método para la composición

    public void iniciarGUI(ControladorRequerimientosReto4 controlador){

        //Propiedades del frame

        setTitle("Menú Principal Reto 5");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(100,100,400,800);

        setBackground(Color.BLUE);

        //Agregar los componentes 
        btnRequerimiento1 = new JButton(this.redimensionarIcono(new ImageIcon("img/proyectos.png"), 64));
        btnRequerimiento1.setText("Ranking Proyectos");
        // Quien me va escuchar 
        btnRequerimiento1.addActionListener(controlador);
        //Que voy a decir para que se haga lo que tengo asociado
        btnRequerimiento1.setActionCommand("rankingProyectos");

        btnRequerimiento2 = new JButton(this.redimensionarIcono(new ImageIcon("img/bancos.png"), 64));        
        btnRequerimiento2.setText("Ranking Bancos");
        btnRequerimiento2.addActionListener(controlador);
        btnRequerimiento2.setActionCommand("rankingBancos");

        btnRequerimiento3 = new JButton(this.redimensionarIcono(new ImageIcon("img/materiales.png"), 64));
        btnRequerimiento3.setText("Ranking Materiales");
        btnRequerimiento3.addActionListener(controlador);
        btnRequerimiento3.setActionCommand("rankingMaterialesImportados");

        /*
        btnCRUD_Materiales = new JButton(redimensionarIcono(new ImageIcon("img/editar.png"), 64));
        btnCRUD_Materiales.setText("Gestión Materiales"); 
        btnCRUD_Materiales.addActionListener(controlador);        
        btnCRUD_Materiales.setActionCommand("crudMateriales");  
        */

        //Menu
        JMenuBar mnuBarra = new JMenuBar();
        JMenu mnuProyectos = new JMenu("Proyectos");
        JMenu mnuBancos = new JMenu("Bancos");
        JMenu mnuMateriales = new JMenu("Materiales");
        JMenuItem mnuMayorGasto = new JMenuItem("Ranking Mayor Gasto");
        JMenuItem mnuAreas = new JMenuItem("Ranking Descendente Bancos por Area");
        JMenuItem mnuDescendenteImportados = new JMenuItem("Ranking Descendente Materiales Importados");        

        mnuMayorGasto.addActionListener(controlador);
        mnuMayorGasto.setActionCommand("rankingProyectos");
        mnuAreas.addActionListener(controlador);
        mnuAreas.setActionCommand("rankingBancos");
        mnuDescendenteImportados.addActionListener(controlador);
        mnuDescendenteImportados.setActionCommand("rankingMaterialesImportados");

        mnuProyectos.add(mnuMayorGasto);
        mnuBancos.add(mnuAreas);
        mnuMateriales.add(mnuDescendenteImportados);

        mnuBarra.add(mnuProyectos);
        mnuBarra.add(mnuBancos);
        mnuBarra.add(mnuMateriales);

        //Contenedor intermedio de botones
        //JPanel panel = new JPanel(new GridLayout(3,1)){};
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());


        //asociar los componentes al contenedor
        panel.add(mnuBarra,BorderLayout.PAGE_START);
        
        //Contenedor intermedio de menú
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(3,1));

        panelBotones.add(btnRequerimiento1,BorderLayout.NORTH);
        panelBotones.add(btnRequerimiento2,BorderLayout.CENTER);
        panelBotones.add(btnRequerimiento3,BorderLayout.SOUTH);

        panel.add(panelBotones);
        //panel.add(btnCRUD_Materiales);

        

        //Contenedor intermedio de menú
        //JPanel panelMenu = new JPanel(new GridLayout(1,1));

        //Asociar el menu al panel Intermedio
        //panelMenu.add(mnuBarra);

        //Asociar el contenedor intermedio de menu al JPanel 
        //getContentPane().add(panelMenu);

        //Asociar el contenedor intermedio de botones al JPanel 
        getContentPane().add(panel);

        // Mostrar la ventana
        setSize(400,400);
        setLocationRelativeTo(null);
        setVisible(true);

    }

    
}