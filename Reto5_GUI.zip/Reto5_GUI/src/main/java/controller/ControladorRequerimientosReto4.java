package controller;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JMenuItem;

// Requerimiento 3
import model.vo.BancoRankeadoAreaPromedio;
import model.dao.BancoRankeadoAreaPromedioDao;
// Requerimiento 5
import model.vo.MaterialRankeadoCompras;
import model.dao.MaterialRankeadoComprasDao;
//Requerimiento 1
import model.vo.ProyectoRankeadoCompras;
import model.dao.ProyectoRankeadoComprasDao;

import view.MenuPrincipalGUI;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JMenuItem;

import model.vo.MaterialConstruccion;
import model.dao.MaterialConstruccionDao;

//View
import view.MenuPrincipalGUI;
import view.Requerimiento1_GUI;
import view.Requerimiento2_GUI;
import view.Requerimiento3_GUI;
//import view.CRUD_Materiales_GUI;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ControladorRequerimientosReto4 implements ActionListener {   

    //Alojar objetos del modelo
    private final ProyectoRankeadoComprasDao proyectoRankeadoComprasDao;
    private final MaterialRankeadoComprasDao materialRankeadoComprasDao;
    private final BancoRankeadoAreaPromedioDao bancoRankeadoAreaPromedioDao;
    private final MaterialConstruccionDao materialConstruccionDao;

    //Alojar objetos de la vista
    private final MenuPrincipalGUI menuPrincipalGUI;
    private Requerimiento1_GUI requerimiento1_GUI;
    private Requerimiento2_GUI requerimiento2_GUI;
    private Requerimiento3_GUI requerimiento3_GUI;
    //private CRUD_Materiales_GUI crud_Materiales_GUI;

    // Constructor
    public ControladorRequerimientosReto4(){

        // Instanciamos los DAO
        this.proyectoRankeadoComprasDao = new ProyectoRankeadoComprasDao();
        this.materialRankeadoComprasDao = new MaterialRankeadoComprasDao();
        this.bancoRankeadoAreaPromedioDao = new BancoRankeadoAreaPromedioDao();
        this.materialConstruccionDao = new MaterialConstruccionDao();
        //Instanciamos las vistas o interfaces
        this.menuPrincipalGUI = new MenuPrincipalGUI();

    }
    
    //Casos de uso

    public ArrayList<ProyectoRankeadoCompras> consultarProyectosCompras10() throws SQLException {
        return this.proyectoRankeadoComprasDao.rankingProyectosComprasDescendente10();
    }
    
    public ArrayList<BancoRankeadoAreaPromedio> consultarBancosRankeadosAreaPromedio() throws SQLException {
        return this.bancoRankeadoAreaPromedioDao.rankingBancosAreaPromedioDescendente();
    }

    public ArrayList<MaterialRankeadoCompras> consultarMaterialesRankeadosCompras() throws SQLException {
        return this.materialRankeadoComprasDao.rankingMaterialesComprasDescendente();
    }

    //Controlador iniciando la aplicación. En caso de que la aplicación inicie en modo gráfico
    public void iniciarAplicacion(){
        this.menuPrincipalGUI.iniciarGUI(this);
    }

    

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand="";
        // Obtener el evento asociado al botón
        Object control=e.getSource();
	    if(control instanceof JButton){
		    actionCommand = ((JButton)e.getSource()).getActionCommand();
	    }
        
        if(control instanceof JMenuItem){
		    actionCommand = ((JMenuItem)e.getSource()).getActionCommand();
	    }
        //String actionCommand = ((JButton)e.getSource()).getActionCommand();
        //String actionCommand = ((JMenuItem)e.getSource()).getActionCommand();

        switch(actionCommand){
            case "rankingProyectos":
                //System.out.println("Interfaz de Proyectos en Construcción");
                try{
                    ArrayList<ProyectoRankeadoCompras> proyectos = new ArrayList<ProyectoRankeadoCompras>();
                    proyectos = this.proyectoRankeadoComprasDao.rankingProyectosComprasDescendente10();
                    this.requerimiento1_GUI = new Requerimiento1_GUI(proyectos);
                }catch(SQLException eProyectosCompras){
                    System.err.println("Error cargando rq1 en la ventana!! "+eProyectosCompras);
                }
                break;
            case "rankingBancos":
                //System.out.println("Interfaz de Bancos en Construcción");
                try{
                    ArrayList<BancoRankeadoAreaPromedio> bancos = new ArrayList<BancoRankeadoAreaPromedio>();
                    bancos = this.bancoRankeadoAreaPromedioDao.rankingBancosAreaPromedioDescendente();
                    this.requerimiento2_GUI = new Requerimiento2_GUI(bancos);
                }catch(SQLException eBancosArea){
                    System.err.println("Error cargando rq2 en la ventana!! "+eBancosArea);
                }
                break;
            case "rankingMaterialesImportados":
                //System.out.println("Interfaz de Materiales en Construcción");
                try {
                    ArrayList<MaterialRankeadoCompras> materiales = new ArrayList<MaterialRankeadoCompras>();
                    materiales = this.materialRankeadoComprasDao.rankingMaterialesComprasDescendente();
                    this.requerimiento3_GUI = new Requerimiento3_GUI(materiales);
                } catch (Exception eMateriales) {
                    System.err.println("Error cargando rq3 en la ventana!! " + eMateriales);
                }
                break;
            
        }
        

    }
    
}
