package util;

// Librerías para la conexión a la base datos y control de errores
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Librerías para archivos
import java.io.File;

public class JDBCUtilities {

    // Ubicación de la base de datos que soporta este SW
    
    private static final String UBICACION_BD = "/home/fredy/Fredy/Capacitación/MINTIC2022/UTP/Ciclo2/21C2PBG61/Clase16/mvc_proyectos_construccion/ProyectosConstruccion.db"; // Ruta absoluta

    // Método para proveer la conexión
    public static Connection getConnection() throws SQLException{

        String url = "jdbc:sqlite:" + JDBCUtilities.UBICACION_BD;
        return DriverManager.getConnection(url);
        
    }

    // Método complementario -> sqlite si no existe la base de datos la crea(vacia)
    public static boolean estaVacia(){
        File archivo = new File(JDBCUtilities.UBICACION_BD);
        return archivo.length() == 0;
    }
    
    // Inicialización de la base de datos
    //...

}