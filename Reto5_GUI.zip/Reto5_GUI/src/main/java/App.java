//Librerías
import java.util.ArrayList;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import view.VistaRequerimientosReto4;
import controller.ControladorRequerimientosReto4;

//****************************************************************
//- Recordar que la clase que contiene el main no debe ser subida.
//- El main se utiliza como ejemplo para los llamados.
//- Tampoco incluir los System.out.println(); 
//  se sugieren como separadores mientras se realizan pruebas.
//- Al subir el reto la base de datos está en la ubicación ofrecida
//  en este esqueleto.
//****************************************************************

public class App {
    public static void main( String[] args ) {  
        
        // Inicio de la aplicación
        ControladorRequerimientosReto4 controlador= new ControladorRequerimientosReto4();
        controlador.iniciarAplicacion();

        // //Intentar conectarnos a la base de datos
        // try(Connection conexion = JDBCUtilities.getConnection()){
            
        //     if(JDBCUtilities.estaVacia()){
        //         System.out.println("Se encuentra vacía!");
        //     }else{
        //         System.out.println("No está vacía BD encontrada");
        //     }

        //     //Iniciaríamos nuestra aplicación
        //     //Llamado al menú de inicio de la vista/view
        //     //MenuLider.iniciar();

        //     MenuLider.mostrarRequerimiento3();

            
        // }catch( SQLException e ){

        //     System.err.println("Error iniciando conexión: "+e);

        // }

    }
}